Thanks for downloading!!
-------------------------------------------------------------
To play the game, simply double-click the Hangman.exe file
-------------------------------------------------------------
Connor Chen - connorjchen2784@yahoo.com for questions

